﻿//using System.Collections.Generic;
//using System.Linq;
//using Microsoft.AspNetCore.Cors.Infrastructure;
//using Microsoft.AspNetCore.Mvc;
//using Shrey.Models;

//namespace Shrey.Controllers
//{
//    public class CartController : Controller
//    {
//        private readonly ICartService _cartService;

//        public CartController(ICartService cartService)
//        {
//            _cartService = cartService;
//        }

//        public IActionResult Index()
//        {
//            var cartItems = _cartService.GetCartItems();
//            return View(cartItems);
//        }

//        public IActionResult AddToCart(int productId)
//        {
//            _cartService.AddToCart(productId);
//            return RedirectToAction("Index");
//        }
//    }
//}