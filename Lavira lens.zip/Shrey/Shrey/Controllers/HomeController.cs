using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Shrey.Data;
using Shrey.Models;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace Shrey.Controllers
{
    public class HomeController : Controller
    {
        private readonly ApplicationDbContext _db;

        public HomeController(ApplicationDbContext db)
        {
            _db = db;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Search(int id)
        {
            var product = _db.Products.Find(id);

            if (product == null)
            {
                return NotFound();
            }

            return RedirectToAction("Detail", new { id });
        }

        public IActionResult Products(string searchQuery)
        {
            // If search query is null or empty, retrieve all products
            if (string.IsNullOrEmpty(searchQuery))
            {
                List<Products> objProductList = _db.Products.ToList();
                return View(objProductList);
            }
            else
            {
                // Retrieve products that match the search query
                List<Products> searchResults = _db.Products.Where(p => p.Name.Contains(searchQuery)).ToList();
                return View(searchResults);
            }
        }


        public IActionResult Detail(int id)
        {
            var product = _db.Products.Find(id);

            if (product == null)
            {
                return NotFound();
            }

            return View(product);
        }

        [HttpPost]
        public async Task<IActionResult> CartPage(int id)
        {
            var product = await _db.Products.FindAsync(id);

            if (product == null)
            {
                return NotFound();
            }

            var cartItem = new Products
            {
                Id = product.Id,
                Name = product.Name,
                Price = product.Price,
                
            };

            // Check if the entity is already tracked, and if not, add it
            var existingCartItem = await _db.Products.FindAsync(cartItem.Id);
            if (existingCartItem == null)
            {
                _db.Products.Add(cartItem);
            }
            else
            {
                // Update the existing tracked entity with the new values
                _db.Entry(existingCartItem).CurrentValues.SetValues(cartItem);
            }

            await _db.SaveChangesAsync();

            return RedirectToAction("CartPage");
        }


        public IActionResult CartPage()
        {
            var cartItems = _db.Products.ToList();
            return View(cartItems);
        }

        public IActionResult Order()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
