﻿using System;
using Microsoft.EntityFrameworkCore;
using Shrey.Models;

namespace Shrey.Data
{
	public class ApplicationDbContext:DbContext
	{
		public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options):base(options)
		{

		}
		public DbSet<Products> Products { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Products>().HasData(
                 new Products { Id = 1, Name = "Titan", Desc = "Titan Frame" ,Price=20},
                 new Products { Id = 2, Name = "Fastrack", Desc = "Fastrack Frame" , Price = 30},
                 new Products { Id = 3, Name = "Crizol", Desc = "Crizol Frame" , Price = 40 },
                 new Products { Id = 4, Name = "Titan", Desc = "Titan Frame" , Price = 50 },
                 new Products { Id = 5, Name = "Fastrack", Desc = "Fastrack Frame" , Price = 60 },
                 new Products { Id = 6, Name = "Titan", Desc = "Titan Frame", Price = 70 },
                 new Products { Id = 7, Name = "Fastrack", Desc = "Fastrack Frame", Price = 80 },
                 new Products { Id = 8, Name = "Titan", Desc = "Titan Frame" , Price = 90 },
                 new Products { Id = 9, Name = "Fastrack", Desc = "Fastrack Frame", Price = 100 },
                 new Products { Id = 10, Name = "Crizol", Desc = "Crizol Frame", Price = 110 }
                 );
        }       
        
    }
}

